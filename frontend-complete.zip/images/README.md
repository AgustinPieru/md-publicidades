# Carpeta de Imágenes

Esta carpeta contiene todas las imágenes estáticas utilizadas en la aplicación.

## Estructura recomendada

```
images/
├── cover.jpg              # Imagen de portada (Home)
├── about.jpg              # Imagen sobre nosotros (About)
└── services/              # Imágenes de servicios
    ├── led-1.jpg
    ├── led-2.jpg
    ├── led-3.jpg
    ├── monocolumnas-1.jpg
    ├── monocolumnas-2.jpg
    ├── monocolumnas-3.jpg
    ├── formatos-1.jpg
    ├── formatos-2.jpg
    ├── formatos-3.jpg
    ├── ruteros-1.jpg
    ├── ruteros-2.jpg
    └── ruteros-3.jpg
```

## Uso en componentes

Las imágenes se referencian desde los componentes usando las constantes definidas en `src/constants/images.ts`.

Ejemplo:
```typescript
import { images } from '../constants/images';

// En el componente
<Box sx={{ backgroundImage: `url('${images.cover}')` }} />
```

## Notas

- Las imágenes deben tener nombres descriptivos
- Se recomienda optimizar las imágenes antes de agregarlas (comprimir, redimensionar si es necesario)
- Las rutas son relativas a la carpeta `public`, por lo que se acceden con `/images/...`

