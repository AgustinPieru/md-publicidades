// Copia este archivo como public/config.js en el servidor (o en build local)
// y ajusta la URL del backend sin necesidad de rebuild del frontend.
// Ejemplos:
// window.API_BASE_URL = 'http://107.21.186.16:3001/api';
// window.API_BASE_URL = '/api'; // si usas reverse proxy

window.API_BASE_URL = '';


